
import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList, Image } from 'react-native';

export default function App() {
  const [items, setItems] = useState([]);
  const [desc, setDesc] = useState('');
  const [qty, setQty] = useState('');
  const [price, setPrice] = useState('');

  const addItem = () => {
    if (!desc) return;
    const newItem = {
      id: Date.now().toString(),
      desc,
      qty: Number(qty || 1),
      price: Number(price || 0),
      total: Number(qty || 1) * Number(price || 0)
    };
    setItems([...items, newItem]);
    setDesc('');
    setQty('');
    setPrice('');
  };

  const totalAmount = items.reduce((sum, i) => sum + i.total, 0);

  return (
    <View style={styles.container}>
      <Image source={require('./assets/logo.png')} style={{ width: 120, height: 120, marginBottom: 10 }} />

      <Text style={styles.title}>Hicon Aircons</Text>
      <Text style={styles.subtitle}>Invoice / Quote Builder</Text>

      <TextInput placeholder="Description" value={desc} onChangeText={setDesc} style={styles.input} />
      <TextInput placeholder="Qty" value={qty} onChangeText={setQty} keyboardType="numeric" style={styles.input} />
      <TextInput placeholder="Unit Price" value={price} onChangeText={setPrice} keyboardType="numeric" style={styles.input} />

      <TouchableOpacity style={styles.button} onPress={addItem}>
        <Text style={styles.buttonText}>Add Item</Text>
      </TouchableOpacity>

      <FlatList
        data={items}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.desc}</Text>
            <Text>Qty: {item.qty} | Total: R {item.total}</Text>
          </View>
        )}
      />

      <View style={styles.totalBox}>
        <Text style={styles.totalText}>Subtotal: R {totalAmount}</Text>
        <Text style={styles.vatText}>
          Prices are exclusive of VAT as the supplier is not registered for VAT in terms of the VAT Act.
        </Text>
        <Text style={styles.totalText}>Total: R {totalAmount}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, marginTop: 40 },
  title: { fontSize: 24, fontWeight: 'bold' },
  subtitle: { marginBottom: 20 },
  input: { borderWidth: 1, padding: 10, marginVertical: 5, borderRadius: 5 },
  button: { backgroundColor: 'red', padding: 12, marginVertical: 10 },
  buttonText: { color: 'white', textAlign: 'center' },
  item: { padding: 10, borderBottomWidth: 1 },
  totalBox: { marginTop: 20, padding: 10, borderTopWidth: 2 },
  totalText: { fontWeight: 'bold' },
  vatText: { fontSize: 10, marginVertical: 5 }
});
